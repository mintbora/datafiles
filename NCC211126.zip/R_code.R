rm(list=ls())

##################################
## 엑셀 데이터 읽기
##################################

# 엑셀파일이 있는 경로 잡기
setwd("C:/Users/User/Desktop")


# 엑셀파일 관련 패키지인 openxlsx 설치 및 로드
# install.packages("openxlsx")
library(openxlsx)

# 해당 파일 내의 시트명 확인하기
getSheetNames("meta.xlsx")




##################################
## 효과크기 및 자료추출
##################################

# install.packages("meta")
library(meta)

# 독립인 두 그룹 - 연속형 자료 -------------------------------------------------------

df = read.xlsx("meta.xlsx", sheet="dat.normand1999")
head(df)


?metacont

# MD
fit = metacont(n.e = n1i, 
               mean.e = m1i, 
               sd.e = sd1i, 
               
               n.c = n2i, 
               mean.c = m2i, 
               sd.c = sd1i, 
               
               studlab = source, 
               data = df, 
               
               sm = "MD")

attributes(fit)

# 개별 연구의 효과크기와 분산
fit$TE
fit$seTE
fit$lower
fit$upper


# SMD
fit = metacont(n.e = n1i, 
               mean.e = m1i, 
               sd.e = sd1i, 
               
               n.c = n2i, 
               mean.c = m2i, 
               sd.c = sd1i, 
               
               studlab = source, 
               data = df, 
               
               sm = "SMD")

# ROM
fit = metacont(n.e = n1i, 
               mean.e = m1i, 
               sd.e = sd1i, 
               
               n.c = n2i, 
               mean.c = m2i, 
               sd.c = sd1i, 
               
               studlab = source, 
               data = df, 
               
               sm = "ROM", 
               
               backtransf=T)




# 독립인 두 그룹 - 이분형 ----------------------------------------------------------

df = read.xlsx("meta.xlsx", "dat.bcg")
head(df)

?metabin


## RR
fit = metabin(event.e = tpos, 
              n.e = ttotal, 
              
              event.c = cpos, 
              n.c = ctotal, 
              
              studlab = paste0(author, " (", year, ")"), 
              data = df, 
              
              sm = "RR", 
              backtransf=T)


## OR
fit = metabin(event.e = tpos, 
              n.e = ttotal, 
              
              event.c = cpos, 
              n.c = ctotal, 
              
              studlab = paste0(author, " (", year, ")"), 
              data = df, 
              
              sm = "OR", 
              backtransf=T)


## RD
fit = metabin(event.e = tpos, 
              n.e = ttotal, 
              
              event.c = cpos, 
              n.c = ctotal, 
              
              studlab = paste0(author, " (", year, ")"), 
              data = df, 
              
              sm = "RD", 
              backtransf=T)




# 독립인 두 그룹 - 계수형 자료 -------------------------------------------------------



df = read.xlsx("meta.xlsx", "dat.hart1999")
head(df)

?metainc

## IRR
fit = metainc(event.e = x1i, 
              time.e = t1i, 
              
              event.c = x2i, 
              time.c = t2i, 
              
              studlab = paste0(study, " (", year, ")"), 
              data = df, 
              
              sm = "IRR", 
              backtrasnf = T)
fit


## IRD
fit = metainc(event.e = x1i, 
              time.e = t1i, 
              
              event.c = x2i, 
              time.c = t2i, 
              
              studlab = paste0(study, " (", year, ")"), 
              data = df, 
              
              sm = "IRD", 
              backtrasnf = T)
fit


# 단일군에서의 결과통합 - 연속형자료 -----------------------------------------------------


df = read.xlsx("meta.xlsx", "dat.hackshaw1998")
head(df)

?metagen

## OR
fit = metagen(TE = yi, 
              seTE = sqrt(vi), 
              
              studlab = paste0(author, " (", year, ")"), 
              data = df, 
              
              sm = "OR", 
              backtransf=T)

fit



# 단일군에서의 결과 통합 - 이분형 자료 ---------------------------------------------------

df = read.xlsx("meta.xlsx", "dat.pritz1997")
head(df)


?metaprop

## Logit-transformed proportion
fit = metaprop(event = xi, 
               n = ni, 
               
               studlab = authors, 
               data = df, 
               
               sm = "PLOGIT", 
               backtransf=T)




# 단일군에서의 결과 통합 - 계수형 자료 ---------------------------------------------------

df = read.xlsx("meta.xlsx", "dat.hart1999")
head(df)

?metarate

fit = metarate(event = x1i, 
               time = t1i, 
               
               studlab = paste0(study, " (", year, ")"), 
               data = df, 
               
               sm = "IRLN", 
               backtransf=T)
fit


# 추정치 통합 - 상관계수 -----------------------------------------------------------

df = read.xlsx("meta.xlsx", "dat.mcdaniel1994")
head(df)

?metacor

fit = metacor(cor = ri, 
              n = ni, 
              
              data = df, 
              sm = "ZCOR")
fit


######################################
## 통합추정치 (고정효과모형 vs. 랜덤효과모형)
######################################

## 독립인 두 그룹 - 연속형 자료

df = read.xlsx("meta.xlsx", "dat.normand1999")
head(df)

?metacont

# MD
fit = metacont(n.e = n1i, 
               mean.e = m1i, 
               sd.e = sd1i, 
               
               n.c = n2i, 
               mean.c = m2i, 
               sd.c = sd1i, 
               
               studlab = source, 
               data = df, 
               
               # 효과크기  
               sm = "MD", 
               backtransf = T, 
               
               # 통합추정치 모형 선택
               comb.fixed = F, 
               comb.random = T, 
               
               
               # 랜덤효과모형의 연구간 분산 선택
               method.tau = "DL",
               
               # 가중치 정의 및 풀링방법
               # method = "Inverse"
               )
 


# 논문예시 1 ------------------------------------------------------------------

e1 = c(5, 6, 15, 28, 3, 32, 13, 40)
n1 = c(6, 7, 24, 38, 4, 37, 16, 58)
e2 = c(2, 26, 24, 2, 4, 7, 2, 13)
n2 = c(12, 36, 52, 4, 16, 11, 3, 16)

fit = metabin(event.e = e1, 
        n.e = n1, 
        event.c = e2, 
        n.c = n2, 
        
        sm = "RR", 
        
        method = "Inverse", 
        method.tau = "DL", 
        
        comb.fixed = F, 
        comb.random = T)


# 논문예시 2 ------------------------------------------------------------------
e1 = c(0, 4, 0, 0, 1, 0, 1, 6)
n1 = c(46, 118, 28, 37, 61, 30, 40, 506)
e2 = c(2, 3, 1, 6, 3, 1, 1, 9)
n2 = c(55, 138, 30, 35, 60, 29, 43, 499)

fit = metabin(event.e = e1, 
              n.e = n1, 
              event.c = e2, 
              n.c = n2, 
              
              sm = "OR", 
              
              method = "Peto", 
              
              comb.fixed = T, 
              comb.random = F)



######################################
## 이질성 검토
######################################


# 독립인 두 그룹 - 연속형 자료 -------------------------------------------------------


df = read.xlsx("meta.xlsx", "dat.normand1999")
head(df)

?metacont

# MD
fit = metacont(n.e = n1i, 
               mean.e = m1i, 
               sd.e = sd1i, 
               
               n.c = n2i, 
               mean.c = m2i, 
               sd.c = sd1i, 
               
               studlab = source, 
               data = df, 
               
               # 효과크기  
               sm = "MD", 
               backtransf = T, 
               
               # 통합추정치 모형 선택
               comb.fixed = F, 
               comb.random = T, 
               
               
               # 랜덤효과모형의 연구간 분산 선택
               method.tau = "DL",
               
               # 가중치 정의 및 풀링방법
               # method = "Inverse"
)


## forestplot
?forest

forest(fit)

library(devEMF)

getwd()

emf("figure.emf", emfPlus=F)
cilayout("(", ", ")
forest(fit, 
       digits=2, 
       
       ## Plot 지정
       xlim=c(-100, 25),
       at=c(-100, -75, -50, -25, 0, 25),
       
       ## Heterogeneity test 지정
       digits.pval=3)

dev.off()

## Radial plot
radial(fit, level=0.95)


# 독립인 두 그룹 - 이분형 ----------------------------------------------------------

df = read.xlsx("meta.xlsx", "dat.bcg")
head(df)

?metabin


## OR
fit = metabin(event.e = tpos, 
              n.e = ttotal, 
              
              event.c = cpos, 
              n.c = ctotal, 
              
              studlab = paste0(author, " (", year, ")"), 
              data = df, 
              
              sm = "OR", 
              backtransf=T, 
              
              
              # 통합추정치 모형 선택
              fixed = F, 
              random = T, 
              
              
              # 랜덤효과모형의 연구간 분산 선택
              method.tau = "DL",
              
              # 가중치 정의 및 풀링방법
              method = "Peto"
              )


## forest
forest(fit, 
       digits=3, 
       digits.pval=3, 
       
       xlim = c(0.01, 10), 
       at = c(0.01, 0.1, 0.5, 1, 2, 10))


## L'Abbe plot
labbe(fit)

## Radial plot
radial(fit, level=0.95)




######################################
## 출판편향검정
######################################

fit

## funnel plot
?funnel

funnel(fit, 
       
       # 효과크기 단위
       backtransf=F, 
       
       # y축 단위
       yaxis="se",
       
       # contour plot
       contour.levels=c(0.90, 0.95, 0.99))


## publication bias test
?metabias

metabias(fit, method.bias="Egger", k.min=5)
metabias(fit, method.bias="Peters", k.min=5)





######################################
## 민감도 분석
######################################

## Copas selection analsysis

# install.packages("metasens")
library(metasens)


## OR
fit = metabin(event.e = tpos, 
              n.e = ttotal, 
              
              event.c = cpos, 
              n.c = ctotal, 
              
              studlab = paste0(author, " (", year, ")"), 
              data = df, 
              
              sm = "OR", 
              backtransf=T, 
              
              
              # 통합추정치 모형 선택
              fixed = F, 
              random = T, 
              
              
              # 랜덤효과모형의 연구간 분산 선택
              method.tau = "DL",
              
              # 가중치 정의 및 풀링방법
              method = "Peto"
)

copas(fit)
plot(fit)



######################################
## 하위군 분석
######################################

df = read.xlsx("meta.xlsx", "ADHD")
head(df)

# 독립인 두 군 (연속형)

?metacont
fit = metacont(n.e = n1, 
               mean.e = m1, 
               sd.e = s1, 
               
               n.c = n2, 
               mean.c = m2, 
               sd.c = s2, 
               
               studlab = study, 
               data = df, 
               
               sm = "SMD", 
               
               # 하위군 분석 그룹
               subgroup = weeks)
fit
forest(fit)




######################################
## 메타회귀분석
######################################


df = read.xlsx("meta.xlsx", "BCG")
head(df)

# 독립인 두 군 (이분형)
?metabin
fit = metabin(event.e = a, 
              n.e = n1, 
              event.c = c, 
              n.c = n2, 
              
              studlab = Study, 
              data=df, 
              
              fixed = F, 
              random = T,
              
              sm = "OR",
              method = "Peto", 
              method.tau = "DL")

# 이질성 평가
forest(fit)


# 출판편향
metabias(fit, method.bias="Peters", k.min=3)
funnel(fit)
labbe(fit)
radial(fit)


# 하위군 분석
fit2 = update(fit, subgroup=allocation)
forest(fit2)


# 메타회귀분석
?metareg

fit3 = metareg(fit, formula = ~latitude)
fit3

fit4 = metareg(fit, formula = ~latitude + factor(Randomization))
fit4

# Bubbleplot
bubble(fit3)
bubble(fit4)














