rm(list=ls())

############################
## 01. R 기초 
############################


# 콘솔창에 입력해보기 -----------------------------------------------------------------

2 + 10
2 - 10
2 * 10
2 / 10

"안녕하세요"
NA
TRUE
T
FALSE
F

# 이건 주석입니다
# 실행되지 않지요

2 + 3    # #뒤만 실행되지 않아요. 



# 변수 할당 -------------------------------------------------------------------

A <- 2
a <- 3
A + a

.bora <- 5
bora <- 10
boracharac <- "안녕"

.bora; bora; boracharac



# R 객체 --------------------------------------------------------------------

# 데이터 프레임 만들기

age <- c(37, 26, 38, 44, 47)
sex <- c("여", "여", "여", NA, "남")
bscore <- c(100, 97, 98, 97, 95)

data1 <- data.frame(age, sex, bscore)

# 객체 크기 확인
length(age)   # age 벡터의 길이
dim(data1)    # data1 데이터 프레임의 차원


# 특정 위치의 데이터값 확인
age[3]                # age의 3번째 원소
x <- sex[c(2,3,5)]    # sex의 2, 3, 5번째 원소를 x에 저장하기
x
data1[4,1]            # data1의 4행 1열 원소
data1[2,]             # data1의 2행 원소
data1[,3]             # data1의 3열 원소


# 데이터 프레임 속 벡터 호출하기

data1$age           # data1의 age벡터 불러내기
x <- data1$bscore   # data1의 bscore 벡터를 x에 저장
y <- data1$sex[1]   # data1의 sex 벡터의 1번째 원소를 y에 저장

x
y



# R 함수 --------------------------------------------------------------------

37 + 26 + 38 + 44 + 47          # age의 합계 계산하기
sum(data1$age)                  # 함수 sum()으로 age 합계 계산
mean(data1$age)                 # 함수 mean()으로 age 평균 계산
sd(data1$bscore)                # 함수 sd()로 bscore 표준편차 게산
table(data1$sex)                # 함수 table()로 sex의 범주별 빈도 계산
table(data1$sex, exclude=NULL)  # sex의 결측치 포함한 빈도 계산



# 함수의 도움말 보기
help(mean)                     # mean 함수의 도움말 확인
?mean                          # mean 함수의 도움말 확인




# R 패키지 -------------------------------------------------------------------

# install.packages("moonBook")
# install.packages(c("dplyr", "ggplot2"), dep=c("Depends", "Imports"))

library(moonBook)
?mytable
?acs


############################
## 02. 데이터 전처리
############################



# 작업 디렉토리 -----------------------------------------------------------------

getwd()                                # 현재 경로 확인
mypath <- getwd()                      # 현재 경로 저장
setwd("C:/Users/mintb/Desktop")        # 바탕화면으로 경로 변경하기1
setwd("C:\\Users\\mintb\\Desktop")     # 바탕화면으로 경로 변경하기2
setwd(mypath)                          # 저장해둔 기존 경로로 변경

setwd("C:/Users/mintb/Desktop/data")   # 데이터 다운받아 압축해제한 폴더 경로 입력


# txt 파일 읽어오기/저장하기 -------------------------------------------------------------

temp <- read.table("temperature.txt", header=T)
temp

humid <- read.table("humidity.txt", header=T, ",")
humid

humid <- read.table("humidity.txt", header=T, sep=",", na.strings=c(".", "NA"))
humid


write.table(temp, "temp_save.txt", row.names=F)
write.table(humid, "humid_save.txt", row.names=F)




# csv 파일 읽어오기/저장하기 -------------------------------------------------------------

read.csv("humidity.txt")
read.csv("humidity.txt", na.strings=c(".", "NA"))
read.csv("temperature.txt", sep=" ")

write.csv(temp, "temp_save.csv", row.names=F)




# xls/xlsx 파일 읽어오기/저장하기 ---------------------------------------------------

# install.packages(c("readxl", "writexl", dep=c("Depends", "Imports")))
library(readxl)
temp <- read_excel("temperature.xlsx")
humid <- read_excel("temperature.xlsx", 2)                     # 시트 순서를 이용한 호출
humid <- read_excel("temperature.xlsx", "humidity")            # 시트 이름을 이용한 호출


library(writexl)
write_xlsx(temp, "temperature2.xlsx")



# SAS / SPSS / STATA 파일 읽어오기 ----------------------------------------------

# install.packages(c("haven", dependencies=c("Depends", "Imports")))
library(haven)

temp1 <- read_spss("temperature.sav")
temp2 <- read_sas("temperature.sas7bdat")
temp3 <- read_stata("temperature.dta")



# 데이터 구조 파악하기 -------------------------------------------------------------

exam <- read.csv("exam.csv")

head(exam)     # 처음 6행 출력
head(exam, 3)  # 처음 3행 출력
tail(exam)     # 마지막 6행 출력
tail(exam, 2)  # 마지막 2행 출력
View(exam)     # 뷰어창에 데이터 출력
colnames(exam) # 변수명 벡터 출력
dim(exam)      # 데이터 차원 출력 (행, 열 순으로 길이 2 벡터가 출력됨)
str(exam)      # 데이터의 차원, 변수명, 변수타입, 초반 데이터 출력



# 요약통계량 출력 ----------------------------------------------------------------

summary(exam)

exam$class <- factor(exam$class)
summary(exam)



# 결측치 ---------------------------------------------------------------------

y <- c(1:3, NA)
y
is.na(y)
is.na("NA")
sum(is.na(y))   # 결측치 개수 카운팅
summary(y)


# 결측치 연산
8 + 2 + NA
8 - 2 + NA
8 * 2 * NA
NA / 2
NA * NA
NA <= 1


age <- c(58, 78, 44, 88, 999, 13, 26, 999)   # 999를 결측치를 사용한 경우
age[age == 999] <- NA                        # 999 부분을 NA로 치환
age 

summary(age)

sum(age)                  # 결측치 포함하여 합계 계산
sum(age, na.rm=TRUE)      # 결측치 제외하여 합계 계산


# 결측치 제거
humid
mean(humid$humidity)
mean(humid$humidity, na.rm=TRUE)

na.omit(humid$humidity)                    # 결측치 있는 행 제거



#######################################
## 03. 기본분석
#######################################



# 정규성 검정 ------------------------------------------------------------------

# 표준정규분포를 따르는 25개 random number 생성하기
x <- rnorm(25)

# Graphical method
par(mfcol=c(1,3))
hist(x, probability=T); lines(density(x), col=2)
boxplot(x); abline(h=mean(x), col=2)
qqnorm(x, pch=20); qqline(x, col=2)




# 두 집단 평균비교 ---------------------------------------------------------------

setwd("C:/Users/mintb/Desktop/data")   
data <- readxl::read_excel("example_data.xlsx", "sbp")
summary(data)

attach(data)

# 요약통계량
table(group)
tapply(sbp, group, mean)
tapply(sbp, group, sd)


# 정규성 검정
shapiro.test(sbp[group=="patient"])
shapiro.test(sbp[group=="normal"])

tapply(sbp, group, shapiro.test)

# 등분산 검정
car::leveneTest(sbp~group, center=mean)

# two samples t-test
t.test(sbp~group, var.equal=T)


# Wilcoxon's ranksum test
wilcox.test(sbp~group)

detach(data)



# 셋 이상 집단 평균 비교 -----------------------------------------------------------



setwd("C:/Users/mintb/Desktop/data")   
data <- readxl::read_excel("example_data.xlsx", "selenium")

attach(data)

# 요약통계량
table(agegp)
tapply(selenium, agegp, summary)

# 정규성검정
shapiro.test(selenium)

# 등분산검정
bartlett.test(selenium ~ agegp, data=data)

# Oneway ANOVA
fit <- oneway.test(selenium ~ agegp, data=data, var.equal=F)
fit

# 사후검정 - Bonferroni's method (가장 보수적)
# 사후검정 - Fisher LSD test (등분산 가정 필요 / 군별 표본수 동일 / 검정력 최대)
# 사후검정 - Tukey HSD test (등분산 가정 필요 / 군별 표본수 무관 / 검정력 중간)
# 사후검정 - Scheffe test (등분산 가정 필요 / 군별 표본수 무관 / 검정력 최소)

# install.packages("DescTools")
library(DescTools)
fit <- aov(selenium ~ agegp, data=data)

PostHocTest(fit, method="bonferroni")
PostHocTest(fit, method="lsd")
PostHocTest(fit, method="hsd")
PostHocTest(fit, method="scheffe")



# Kruskal-Wallis test
fit <- kruskal.test(selenium ~ agegp, data=data)
fit

# 사후검정 - Dunn test using Bonferroni's method (가장 보수적)

# install.packages("dunn.test")
library(dunn.test)
dunn.test(selenium, agegp, method="bonferroni")


detach(data)



# 비율비교 --------------------------------------------------------------------

data <- readxl::read_excel("example_data.xlsx", "rms")

attach(data)

# 빈도표
table(rms, stlbn)
prop.table(table(rms, stlbn), 2)

x <- table(rms, stlbn)
y <- round(prop.table(x, 2)*100, 1)

result <- matrix(paste0(x, " (", y, "%)"), nrow=2))
rownames(result) <- c("Normal", "RMS")
colnames(result) <- c("None", "Stillbirth")
                 
# 카이제곱검정
chisq.test(rms, stlbn)
chisq.test(x)
                 
detach(data)


# 빈도표 직접 입력

tab <- matrix(c(2,3,2,13), nrow=2)

# 카이제곱검정
chisq.test(tab)

# Fisher's exact test
fisher.test(tab)



# Table 1 한번에 뽑기 ----------------------------------------------------------

library(moonBook)

# 환자군과 대조군에서 수축기혈압 비교하기
data <- readxl::read_excel("example_data.xlsx", "sbp")
mytable(group ~ sbp, data=data, method=1)   # t-test
mytable(group ~ sbp, data=data, method=2)   # Wilcoxon's ranksum test
mytable(group ~ sbp, data=data, method=3)   # 정규성 검정 결과에 따라 자동 선택

# 소의 연령군에 따른 셀레늄 농도 비교하기
data <- readxl::read_excel("example_data.xlsx", "selenium")
mytable(agegp ~ selenium, data=data, method=1)  # one-way ANOVA
mytable(agegp ~ selenium, data=data, method=2)  # Kruskal-Wallis test
mytable(agegp ~ selenium, data=data, method=3)  # 정규성 검정 결과에 따라 자동 선택


# 산모의 사산과거력에 따른 아동기 횡문근육종의 비율 차이
data <- readxl::read_excel("example_data.xlsx", "rms")
mytable(stlbn ~ rms, data=data, catMethod=1)   # 연속성수정한 카이제곱검정
mytable(stlbn ~ rms, data=data, catMethod=2)   # 연속성수정안한 카이제곱검정
mytable(stlbn ~ rms, data=data, catMethod=3)   # Fisher's exact test
mytable(stlbn ~ rms, data=data, catMethod=0)   # 가정 검정 결과에 따라 자동 선택


# mytable 결과 저장하기 
re <- mytable(stlbn ~ rms, data=data, catMethod=0) 
mycsv(re, file="T1.csv")


################################################
## 같이 해보기
################################################

rm(list=ls())

#1. data 폴더 내의 birth.csv 파일을 호출해서 birth 데이터 프레임으로 할당하세요. 
setwd("C:/Users/mintb/Desktop/data")   
birth <- read.csv("birth.csv")

#2. birth 데이터의 구조를 파악해보세요. 
head(birth)
tail(birth)
dim(birth)
str(birth)
summary(birth)

#3. birth 데이터에서 신생아 성별(sex)에 따라 출생체중(bweight)가 유의하게 다른지 비교하시오. 
library(moonBook)
mytable(sex ~ bweight, data=birth, method=3)


#4. birth 데이터에서 산모의 고혈압여부(mhtn)에 따라 신생아의 저체중출생(lowbw)이 유의하게 다른 비율을 갖는지 확인하시오. 
mytable(mhtn ~ lowbw, data=birth, catMethod=0)


#5. birth 데이터 전체의 Table1을 뽑아보세요. 
mytable(birth)

#6. birth 데이터에서 신생아 성별(sex)에 따라 출생체중(bweight), 저체중출생여부(lowbw), 재태주수(gest)를 비교하시오.
mytable(sex ~ bweight + lowbw + gest, data=birth, method=1, catMethod=0)

#7. birth 데이터에서 성별에 따라 나머지 모든 변수를 비교하시오. 
mytable(sex ~., data=birth, method=1, catMethod=0)

#8. birth 데이터에서 지역(region)에 따라 나머지 모든 변수를 비교하시오. 
mytable(region~., data=birth, method=1, catMethod=0)

#9. birth 데이터에서 진단(Dx)에 따라 나머지 모든 변수를 비교할 때, total 값도 보이게 하시오. 
mytable(region~., data=birth, method=1, catMethod=0, show.total=T)

#10. #9의 결과를 csv 파일로 저장하시오. 
result <- mytable(region~., data=birth, method=1, catMethod=0, show.total=T)
mycsv(result, file="T1_birth.csv")

#11. birth 데이터에서 신생아 남녀에서 각각 산모의 고혈압 여부에 따른 출생체중, 재태주수, 산모나이를 비교하시오. 
mytable(sex + mhtn ~ bweight + gest + mage, data=birth, method=1)


################################################
## moonBook package 내의 acs 데이터 
################################################


#1. data 폴더 내의 acs.csv 파일을 호출해서 acs 데이터 프레임으로 할당하세요. 
#2. acs 데이터의 구조를 파악해보세요
#3. acs 데이터에서 성별(sex)에 따른 BMI(BMI)가 유의하게 다른지 비교하시오. 
#4. acs 데이터에서 성별(sex)에 따라 흡연력(smoking)이 유의하게 다른 비율을 갖는지 확인하시오. 
#5. acs 데이터 전체의 Table1을 뽑아보세요. 
#6. acs 데이터에서 성별에 따라 연령, BMI, TC, LDLC, HDLC, TG, DM, smoking을 비교하시오.
#7. acs 데이터에서 성별에 따라 나머지 모든 변수를 비교하시오. 
#8. acs 데이터에서 진단(Dx)에 따라 나머지 모든 변수를 비교하시오. 
#9. acs 데이터에서 진단(Dx)에 따라 나머지 모든 변수를 비교할 때, total 값도 보이게 하시오. 
#10. #9의 결과를 csv 파일로 저장하시오. 
#11. acs 데이터에서 남녀에서 각각 당뇨에 따른 age, BMI, smoking을 비교하시오. 





