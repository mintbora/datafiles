

# -------------------------------------------------------------------------


# install.packages("ggplot2")
library(ggplot2)
data(iris)

# iris data로 산점도 그려보기
ggplot(iris) + 
    aes(Sepal.Length, Sepal.Width) + 
    geom_point()

# geom_point() 안에 다양한 옵션 넣기
ggplot(iris) +
    aes(Sepal.Length, Sepal.Width) + 
    geom_point(color="red", size=1)



# -------------------------------------------------------------------------


ggplot(iris) + 
     aes(Sepal.Length, Sepal.Width, color=Species) + 
     geom_point()


## ---------------------------------------------------------------------
ggplot(iris) + 
    aes(Sepal.Length, Sepal.Width, color=Species) + 
    geom_point(position="jitter", alpha=0.5) + 
    xlim(5,7)


## ---------------------------------------------------------------------
# 자동차 class의 개수에 대한 막대그림
ggplot(mpg) + 
    aes(class) + 
    geom_bar()


## ---------------------------------------------------------------------

# class별로 색상 다르게 주기
ggplot(mpg) +
    aes(class, color=class) + 
    geom_bar()

ggplot(mpg) + 
    aes(class, fill=class) + 
    geom_bar()


## ---------------------------------------------------------------------
ggplot(mpg) + aes(hwy, fill=class) + geom_bar()
ggplot(mpg) + aes(hwy, fill=class) + geom_bar(position="dodge")
ggplot(mpg) + aes(hwy, fill=class) + geom_bar(position="stack")
ggplot(mpg) + aes(hwy, fill=class) + geom_bar(position="fill")



# -------------------------------------------------------------------------


# economics 데이터
# 날짜에 따른 인구수와 실업자수 데이터 포함
# ?economics
data(economics)
str(economics)


## ---------------------------------------------------------------------
# 날짜에 따른 실업자수 선 그래프
ggplot(economics) + 
    aes(date, unemploy) + 
    geom_line()

# 날짜에 따른 실업률(실업자수/인구수) 선그래프
ggplot(economics) + 
    aes(date, unemploy/pop) + 
    geom_line()


## ---------------------------------------------------------------------
ggplot(economics) + 
    aes(date, unemploy/pop) + 
    geom_line() + 
    xlim(as.Date("1967-07-01"), as.Date("1977-07-01"))


## ---- message=F-------------------------------------------------------
ggplot(economics) + 
    aes(date, unemploy/pop) + 
    geom_step() + 
    xlim(as.Date("1967-07-01"), as.Date("1977-07-01"))


## ---------------------------------------------------------------------
ggplot(iris, aes(Sepal.Length, Sepal.Width)) + 
    geom_point() + 
    geom_line()


## ---------------------------------------------------------------------
ggplot(iris) + 
    geom_point(aes(Sepal.Length, Sepal.Width), color="red") + 
    geom_point(aes(Sepal.Length, Petal.Length), color="blue")


## ---------------------------------------------------------------------
ggplot(mpg) + aes(hwy, fill=class) + geom_density()
ggplot(mpg) + aes(hwy, fill=class) + geom_density(alpha=0.5)


## ---------------------------------------------------------------------
ggplot(iris) + aes(Sepal.Length) + geom_dotplot()
ggplot(iris) + aes(Sepal.Length) + geom_dotplot(binwidth=0.1)
ggplot(iris) + aes(Sepal.Length) + geom_dotplot(binwidth=0.1, stackdir="centerwhole")

ggplot(iris) + 
    aes(Species, Sepal.Length) + 
    geom_dotplot(binaxis="y")

ggplot(iris) + 
    aes(Species, Sepal.Length) + 
    geom_dotplot(binaxis="y", stackdir="center")


ggplot(iris) + 
    aes(Species, Sepal.Length, color=Species) + 
    geom_dotplot(binaxis="y", stackdir="center")


ggplot(iris) + 
    aes(Species, Sepal.Length, fill=Species) + 
    geom_dotplot(binaxis="y", stackdir="center")


## ---------------------------------------------------------------------
ggplot(iris) + 
    aes(Species, Sepal.Length) + 
    geom_violin()


# geom_violin과 geom_dotplot 겹쳐 그리기
ggplot(iris) + 
    aes(Species, Sepal.Length) +
    geom_dotplot(aes(fill=Species), binaxis="y", stackdir="center") +
    geom_violin()

# violin plot을 뒤로 보내기
ggplot(iris) + 
    aes(Species, Sepal.Length) +
    geom_violin() + 
    geom_dotplot(aes(fill=Species), binaxis="y", stackdir="center")


## ---------------------------------------------------------------------
ggplot(iris) +
    aes(Species, Sepal.Length, color=Species) + 
    geom_jitter()


ggplot(iris) +
    aes(Species, Sepal.Length, color=Species) + 
    geom_jitter(width=0.25, height=0.25, alpha=0.5)


## ---------------------------------------------------------------------
ggplot(iris) + 
    aes(Species, Sepal.Length, color=Species) + 
    geom_boxplot()



## ---- fig.width=9, fig.height=6, messages=F, warning=F----------------
library(ggplot2)

ggplot(mpg) + 
    geom_point(aes(cty, hwy, color=cyl)) -> pp

pp + labs(title="Fuel Economy Data", 
          subtitle="from 1999 and 2008 \n for 38 popular models of car", 
          caption="Fig. 1. This dataset contains a subset of the fuel economy data.", 
          x="Miles per gallon in the city", 
          y="Miles per gallon in the highway", 
          color="No. of cylinder")




# -------------------------------------------------------------------------


p <- ggplot(iris) + geom_point(aes(Sepal.Length, Sepal.Width))
p + expand_limits(x=0, y=0) + geom_point(aes(x=0,y=0), color="red", size=1.5) -> p1
p + expand_limits(x=c(0, 10), y=c(0, 10)) + geom_point(aes(0,0), color="red", size=1.5) + geom_point(aes(10,10), color="red", size=1.5)   -> p2
gridExtra::grid.arrange(p1, p2, layout_matrix=rbind(c(1,2)))



# -------------------------------------------------------------------------


p + xlim(5,7) + ylim(2,4) -> p1                         # 축 범위 지정하기
p + scale_x_continuous(breaks = c(5, 5.6, 7)) -> p2     # breaks 직접 지정
p + scale_x_continuous(trans="log2", breaks=4:8)  -> p3 # 로그스케일로 변환

gridExtra::grid.arrange(p1, p2, p3, layout_matrix=rbind(c(1,2,3)))



# -------------------------------------------------------------------------


p + xlab("Sepal length") + ylab("Sepal width") -> p1
p + coord_flip() -> p2
p + scale_x_reverse() -> p3

gridExtra::grid.arrange(p1, p2, p3, layout_matrix=rbind(c(1,2,3)))



# -------------------------------------------------------------------------


ggplot(economics) + 
    geom_line(aes(date, unemploy/pop)) -> p 


p + scale_x_date(date_labels="%Y") -> p1   # %YYYY로 표기
p + scale_x_date(date_labels="%Y-%m") -> p2 # yyyy-mm로 표기
p + scale_x_date(date_labels="%y-%m") -> p3 # yy-mm로 표기

p + scale_x_date(date_labels="%y", date_breaks="5 years") -> p4 # 5년 단위 눈금
p + scale_x_date(date_labels="%y", date_breaks="10 year") -> p5 # 10년 단위 눈금

gridExtra::grid.arrange(p1, p2, p3, layout_matrix=rbind(c(1,2,3)))
gridExtra::grid.arrange(p4, p5, layout_matrix=rbind(c(1,2)))



# -------------------------------------------------------------------------


ggplot(mpg) + geom_bar(aes(class, fill=drv), position="dodge2") -> p

# 범례 위치
p + theme(legend.position="bottom")  -> p1
p + theme(legend.position=c(0.1, 0.8))  -> p2

# 범례 방향
p + theme(legend.position=c(0.1, 0.8), legend.direction="horizontal") -> p3

# 범례 제목 변경
p + theme(legend.position="right") + labs(fill="New Selection") -> p4

gridExtra::grid.arrange(p1, p2, p3, p4, layout_matrix=matrix(1:4, nrow=2, byrow=T))



# -------------------------------------------------------------------------


ggplot(mpg) + geom_point(aes(displ, cty, color=cty)) -> p

p + scale_x_continuous(name="city miles per gallon") -> p1
p + labs(color="number of cylinders") -> p2
p + theme(legend.position="bottom") -> p3
p + guides(color="colorbar") -> p5
p + guides(color="legend") -> p6
p + scale_color_continuous(labels=c("two", "three", "four", "five", "six", "seven")) -> p7

gridExtra::grid.arrange(p1, p2, p3, layout_matrix=rbind(1:3))
gridExtra::grid.arrange(p5, p6, p7, layout_matrix=rbind(1:3))



# -------------------------------------------------------------------------


ggplot(mpg) + 
    geom_bar(aes(x=class, fill=class)) -> p


p + scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "navy", "gray"))->p1
p + scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "navy", "gray"), 
                      breaks = c("2seater", "suv")) -> p2
p + scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "navy", "gray"), 
                      breaks = c("2seater", "suv"), 
                      labels = c("2 seaters", "SUV"), 
                      name = "Class") -> p3
p + scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "navy", "gray"), 
                      breaks = c("2seater", "suv"), 
                      labels = c("2 seaters", "SUV"), 
                      name = "Class", 
                      limits = c("2seater", "suv")) -> p4
gridExtra::grid.arrange(p1, p2, p3, p4, layout_matrix=matrix(1:4, nrow=2, byrow=T))


# -------------------------------------------------------------------------


p + scale_fill_manual(values=rainbow(10)) -> p1   # 빨간색에서 보라색까지 무지개 구분개수 지정하여 색 사용
p + scale_fill_manual(values=rainbow(10, start=0.5)) -> p2  # 시작점(빨간색) 변경 가능 (0~1)
p + scale_fill_grey(start=0.2, end=0.8) -> p3
p + scale_fill_brewer(palette="Dark2") -> p4

gridExtra::grid.arrange(p1, p2, p3, p4, layout_matrix=matrix(1:4, nrow=2, byrow=T))



# -------------------------------------------------------------------------


library(RColorBrewer)
library(jcolors)
ggplot(mpg) + geom_point(aes(displ, hwy, color=drv)) -> p

p + scale_color_brewer(palette="Accent") -> p1
p + scale_color_jcolors(palette="default") -> p2

gridExtra::grid.arrange(p1, p2, layout_matrix=matrix(1:2, nrow=1))



# -------------------------------------------------------------------------


ggplot(ToothGrowth) + 
    geom_boxplot(aes(factor(dose), len, color=factor(dose))) -> p

p + scale_color_brewer(palette="Accent") -> p1
p + scale_color_jcolors(palette="default") -> p2
gridExtra::grid.arrange(p1, p2, layout_matrix=matrix(1:2, nrow=1))


# -------------------------------------------------------------------------


ggplot(ToothGrowth) + 
    geom_boxplot(aes(factor(dose), len, fill=factor(dose))) -> p

p + scale_fill_brewer(palette="Accent") -> p1
p + scale_fill_jcolors(palette="default") -> p2
gridExtra::grid.arrange(p1, p2, layout_matrix=matrix(1:2, nrow=1))


# -------------------------------------------------------------------------


ggplot(mpg) + 
    geom_jitter(aes(displ, hwy, shape=class)) -> p
p + scale_shape_manual(values=1:7, 
                       breaks=c("2seater", "suv"), 
                       limits=c("2seater", "suv"))



## ---------------------------------------------------------------------
# mpg에서 자동차 종류(class)에 따른 배기량 대비 고속도로 연비
ggplot(mpg) + 
    geom_jitter(aes(displ, hwy, col=class)) -> p

# 고속도로연비가 20, 30, 40인 부분에 라인을 긋고자 함
p + geom_hline(yintercept=c(20, 30, 40), linetype=3, size=1, col="red")

# 고속도로연비가 20~40사이인 영역이 관심부분이라 이쪽 부분의 배경색을 변경하고자 하는 경우
# p + geom_rect(xmin=-Inf, xmax=Inf, ymin=20, ymax=40, fill="lightgray")
ggplot(mpg) + 
    aes(displ, hwy, col=class) + 
    geom_rect(xmin=-Inf, xmax=Inf, ymin=20, ymax=40, fill="lightgray", color="red", alpha=0.5) + 
    geom_jitter()

# 제일 큰 도시연비를 갖는 개체를 화살표로 가리키고 싶을 경우
imax <- which.max(mpg$cty)
ax <- mpg$displ[imax]
ay <- mpg$hwy[imax]

p +  geom_segment(x=ax+1, y=ay, xend=ax+0.05, yend=ay, arrow=arrow(length=unit(5, "mm")), linetype=1, size=1.2)



# -------------------------------------------------------------------------


ggplot(ToothGrowth) + 
     geom_boxplot(aes(factor(dose), len, fill=factor(dose))) + 
     facet_grid(.~supp) -> p

p + theme_bw() + labs(title="theme_bw()") -> p2
p + theme_linedraw() + labs(title="theme_lindraw()") -> p3
p + theme_light() + labs(title="theme_light()") -> p4
p + theme_dark() + labs(title="theme_dark()") -> p5
p + theme_minimal() + labs(title="theme_minimal()") -> p6
p + theme_classic() + labs(title="theme_classic()") -> p7
p + theme_void() + labs(title="theme_void()") -> p8
p + theme_test() + labs(title="theme_test()") -> p9
gridExtra::grid.arrange(p2, p3, p4, p5, p6, p7, p8, p9, nrow=4)


## ---- fig.width=15, fig.height=8--------------------------------------
ggplot(ToothGrowth) + 
     geom_boxplot(aes(factor(dose), len, fill=factor(dose))) -> p

p -> p1
p + theme_bw() -> p2
p + theme_linedraw() -> p3
p + theme_dark() -> p4

library(gridExtra)
grid.arrange(p1, p2, p3, p4, 
             widths=c(2, 1, 1), 
             layout_matrix=rbind(c(1,2,NA), 
                                 c(3,3,4)))

