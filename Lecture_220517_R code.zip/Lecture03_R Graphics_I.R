


#   -----------------------------------------------------------------------


par(mfrow=c(2,4))
plot(x=a, y=b, type="p", main="type='p'")   
plot(a, b, type="l", main="type='l'")       # for lines
plot(a, b, type="b", main="type='b'")       # for both (points and lines)
plot(a, b, type="o", main="type='o'")       # for overlapping (points and lines)
plot(a, b, type="h", main="type='h'")       # for histogram (vertical lines)
plot(a, b, type="s", main="type='s'")       # for stair steps
plot(a, b, type="n", main="type='n'")       # for no plotting


# -------------------------------------------------------------------------


library(moonBook)
data(acs)
attach(acs)

par(mfrow=c(1,2))
hist(x=age)                                # age로 히스토그램 작성
hist(age,                                  # age로 히스토그램 작성
     breaks=40,                            # 셀 개수
     xlim=c(30,90),                        # x축 범위
     ylim=c(0, 100),                       # y축 범위
     main="Histogram of age in acs data",  # 그래프 제목
     xlab="Age (year)",                    # x축 제목
     ylab="Frequency")                     # y축 제목
detach(acs)


# -------------------------------------------------------------------------
library(datasets)

par(mfrow=c(1,2))
plot(longley$Year, longley$Employed, type="p", cex.lab=0.75, main='type="p"')        
plot(longley$Year, longley$Employed, type="l", cex.lab=0.75, main='type="l"')          


# -------------------------------------------------------------------------
library(datasets)

attach(longley)  
par(mfrow=c(2,2))
plot(Year, Employed, type="l", lty="dashed", main="lty='dashed'") 
plot(Year, Employed, type="l", lty=5, main="lty=5(longdash)")                       
plot(Year, Employed, type="l", lty=3, lwd=2, col="red", main="lty=3(dotted), lwd=2, col='red'")     
plot(Year, Employed, type="l", lty=4, lwd=3.5, col="green", main="lty=4, lwd=3.5, col='green'") 


# -------------------------------------------------------------------------
par(mfcol=c(2,3))

pie(rep(1,9), col=0:8, labels=0:8)
plot.new()

attach(longley)
plot(Year, Employed, type="l", col=4, main="col=4", lwd=2)
plot(Year, Employed, type="l", col="blue", main="col='blue'", lwd=2)
plot(Year, Employed, type="l", col="#0000FF", main="col='#0000FF'", lwd=2)
plot(Year, Employed, type="l", col=rgb(0,0,255,max=255), main="col=rgb(0,0,255)", lwd=2)
detach(longley)

# -------------------------------------------------------------------------
# Year에 따른 Employed에 대한 선도표 작성
plot(longley$Year, longley$Employed,            
     type="l", 
     col="darkviolet", 
     lwd=3, 
     main="No. of employed people on 1947-1962",
     xlab="Year", 
     ylab="No. of employed people", 
     cex.main=0.9, 
     cex.lab=0.8, 
     cex.axis=0.75)


# Year에 따른 Employed에 대한 회귀모형 적합
fit <- lm(Employed ~ Year, data=longley)

# 그림 위에 회귀선 추가
abline(fit, lty=2, lwd=1, col="gray80")

# 그림 위에 텍스트 추가
text(x=1950, y=70, labels="R2 = 0.9435 (p<0.001)", cex=0.8, font=2)



# -------------------------------------------------------------------------
data(iris)

plot(iris$Sepal.Length, iris$Petal.Length,   # x, y 지정
     type="p",                               # point (default)
     pch=16,                                 # type of point
     col="firebrick3",                       # color of point
     cex=0.8,                                # size of point
     main="Iris characteristics by Species", # title
     xlab="Sepal Length",                    # x label
     ylab="Petal Length",                    # y label
     col.main=1,                             # 그래프 제목 색상
     col.axis=2,                             # 축 눈금 색상
     col.lab=3)                              # 축 이름 색상


# -------------------------------------------------------------------------
par(mfrow=c(2,2), mar=c(4,4,1,1))
plot(iris$Sepal.Length, iris$Petal.Length, pch=16, col=1, cex.lab=0.8, cex.axis=0.75)
plot(iris$Sepal.Length, iris$Petal.Length, pch=16, col=iris$Species, cex.lab=0.8, cex.axis=0.75)
plot(iris$Sepal.Length, iris$Petal.Length, pch=16, col=c("blue", "red", "green"), cex.lab=0.8, cex.axis=0.75)
text(7.2, 2, "Wrong", cex=1.3, font=2, col="red", adj=0.5)
plot(iris$Sepal.Length, iris$Petal.Length, pch=16, col=c("blue", "red", "green")[iris$Species], cex.lab=0.8, cex.axis=0.75)


# -------------------------------------------------------------------------
# 그룹별 모수 지정
mypch = c(15, 16, 17)
mycol = c("darkcyan", "darkgoldenrod2", "brown1")

# 그룹별 점 종류와 색상을 달리한 scatterplot 작성
plot(iris$Sepal.Length, iris$Petal.Length,   # x, y 지정
     type="p",                               # point (default)
     pch=mypch[iris$Species],                # type by Species
     col=mycol[iris$Species],                # color by Species
     cex=0.8,                                # size of point
     main="Iris characteristics by Species", # title
     xlab="Sepal Length (cm)",               # x label
     ylab="Petal Length (cm)")               # y label

# 범례 추가
legend(x=4.5, y=7, pch=mypch, col=mycol, legend=c("setosa", "versicolor", "virginica"))
legend("bottomright", pch=mypch, col=mycol, legend=levels(iris$Species), lty=1, bty="n")





# -------------------------------------------------------------------------


par(mfrow=c(1,2), mar=c(4,4,3,4))
# 세로형
boxplot(iris$Sepal.Length ~ iris$Species,   # y~x 지정
        col="navy",                         # 박스 색상   
        border="darkcyan",                  # 테두리 색상
        main="Sepal Length by Species",     # 그래프 제목
        xlab="Species",                     # x축 이름
        ylab="Sepal Length",                # y축 이름
        cex.main=1.1,                       # 그래프 제목 글자 크기
        cex.axis=0.8,                       # 축 눈금 글자 크기
        cex.lab=0.9)                        # 축 이름 글자 크기


# 가로형 + notch 부여 + las 1 부여
boxplot(iris$Sepal.Length ~ iris$Species,   # y~x 지정
        col="navy",                         # 박스 색상   
        border="darkcyan",                  # 테두리 색상
        main="Sepal Length by Species",     # 그래프 제목
        xlab="Sepal Length",                # x축 이름
        ylab="",                            # y축 이름
        horizontal=T,                       # 가로로 누운 박스플롯
        notch=T,                            # notch 주기
        las=1,                              # 축 눈금 아래 보기
        cex.main=1.1,                       # 그래프 제목 글자 크기
        cex.axis=0.8,                       # 축 눈금 글자 크기
        cex.lab=0.9)                        # 축 이름 글자 크기





# -------------------------------------------------------------------------


par(mfrow=c(1,2), mar=c(4,5,1,6))
smoke <- factor(acs$smoking, levels=c("Never", "Ex-smoker", "Smoker"))
tab <- table(smoke)

# 세로형
barplot(tab,                                              # height 
        names.arg = c("None", "Ex-smoking", "Smoking"),   # 막대 라벨
        col = "navy",                                     # 막대 색상
        border = "darkcyan",                              # 막대 테두리 색상
        lwd=2, 
        ylim=c(0,500), cex.axis=0.8)                                    # y축 범위

# 가로형
barplot(tab,                                              # height 
        names.arg = c("None", "Ex-smoking", "Smoking"),   # 막대 라벨
        las = 1,                                          # 축 눈금 아래 보기
        col = "navy",                                     # 막대 색상
        border = "darkcyan",                              # 막대 테두리 색상
        lwd=2, 
        font.axis = 4,                                    # 축 눈금 굵은 이탤릭체체 
        horiz=T,                                          # 가로 막대 그래프
        xlim=c(0,500), cex.axis=0.8)                                    # x축 범위




# -------------------------------------------------------------------------


tab <- table(acs$sex, acs$smoking)

par(mfrow=c(1,2), mar=c(4,4,1,1))
barplot(tab, legend=T, cex.axis=0.8)
barplot(tab, beside=T, col="white", border=c("steelblue", "gold"), cex.axis=0.8)
legend("topleft", legend=c("Female", "Male"), col=c("steelblue", "gold"), pch=15, bty="n")




# -------------------------------------------------------------------------


xx <- par()
class(xx); length(xx)



# -------------------------------------------------------------------------


opar <- par(no.readonly=T)  # 현재 모수 설정 저장
par(mfrow=c(2,2), mar=c(4,4,1,1))
mpg <- ggplot2::mpg
plot(mpg$displ, mpg$hwy, type="p", col="navy", pch=17)
plot(mpg$cty,  mpg$hwy, col="navy", pch=17)
plot(mpg$displ, mpg$hwy)
plot(mpg$displ, mpg$hwy, pch=17, col="navy")
par(opar)



# -------------------------------------------------------------------------


par(mfcol=c(3,3),    # 영역 분할 (3행 3열)
    mar=c(4,3,3,1),  # 내부 마진 영역 
    oma=c(0,0,3,0))  # 외부 마진 영역

plot(mpg$displ, mpg$hwy, pch=19, col=4, main="col=4")
plot(mpg$displ, mpg$hwy, pch=19, col="blue", main="col='blue'")
plot(mpg$displ, mpg$hwy, pch=19, col="#0000FF", main="col='#0000FF'")
plot(mpg$displ, mpg$hwy, pch=19, col=rgb(0,0,255,max=255), main="col=rgb(0,0,255)")

plot.new()   # 빈 그림 삽입

plot(mpg$displ, mpg$hwy, pch=15, col=2, main="col=2")
plot(mpg$displ, mpg$hwy, pch=15, col="red", main="col='red'")
plot(mpg$displ, mpg$hwy, pch=15, col="#FF0000", main="col='#FF0000'")
plot(mpg$displ, mpg$hwy, pch=15, col=rgb(255,0, 0, max=255), main="col=rgb(255,0,0)")


# -------------------------------------------------------------------------


par(opar)

par(mfrow=c(2,2))
plot(mpg$displ, mpg$hwy, font.main=1, main="font=1 (plain)")
plot(mpg$displ, mpg$hwy, font.main=2, main="font=2 (bold)")
plot(mpg$displ, mpg$hwy, font.main=3, main="font=3 (italics)")
plot(mpg$displ, mpg$hwy, font.main=4, main="font=4 (bold italics)")



# -------------------------------------------------------------------------


par(mfrow=c(1,2), mar=c(4,4,1,3))
# R 기본 폰트 적용
plot(mpg$displ, mpg$hwy, family = "mono")
text(4, 40, "mono", family = "mono")
text(5, 35, "sans", family = "sans")
text(6, 40, "serif", family = "serif")

# 구글에서 다운받은 폰트 사용
# install.packages("showtext")
library(showtext)

font_add_google("Nanum Pen Script", family="nanumpen")  # 구글에서 다운로드
showtext_auto()                                         # showtext 자동 시작
plot(mpg$displ, mpg$hwy, 
     xlab="배기량", 
     ylab="고속도로연비", 
     family="nanumpen", 
     cex.lab=3)




# -------------------------------------------------------------------------


par(opar)

# 폰트 다운받기
library(showtext)
font_add_google("Courier Prime", family="courierprime")
showtext_auto()

# plot() 안에서 제목, 축이름 쓰기
par(family="courierprime", mfrow=c(1,2))
plot(mpg$displ, mpg$hwy, pch=16, cex=0.8, col="navy", 
     main="Scatter plot of highway miles per gallon vs. engine displacement", 
     xlab="Engine displacement (in liters)", 
     ylab="Highway (mpg)", 
     cex.main=1.5, 
     cex.lab=1.2, 
     font.main=4, 
     font.lab=2, 
     las=1)

# title()로 제목, 축이름 쓰기
plot(mpg$displ, mpg$hwy, pch=13, cex=0.8, col="firebrick3", ann=F)
title(main="Scatter plot of highway miles per gallon vs. engine displacement", 
      cex.main=1.5, font.main=3)
title(xlab="Engine displacement (in liters)", cex.lab=1.2, font.lab=3)
title(ylab="Highway miles per gallon", cex.lab=1.2, font.lab=2)




# -------------------------------------------------------------------------


par(mfrow=c(1,2))
plot(mpg$displ, mpg$hwy, axes=F, cex=0.8)      # 축 제거
axis(side=1)                          # x축 추가
axis(2)                               # y축 추가


# change axis tick-marks
# summary(mpg$displ)
# summary(mpg$hwy)
plot(mpg$displ, mpg$hwy, axes=F)
axis(1, at=1:8)
axis(1, at=seq(1.5, 7.5, 1), labels=F, tcl=-0.3)
axis(2, at=seq(10, 50, 5), tcl=-0.5, las=2)

# remove axis tick labels
par(mfrow=c(1,3))
plot(mpg$displ, mpg$hwy, xaxt="n", main="xaxt='n'", cex.lab=2, cex.main=2.4)
plot(mpg$displ, mpg$hwy, yaxt="n", main="yaxt='n'", cex.lab=2, cex.main=2.4)
plot(mpg$displ, mpg$hwy, xaxt="n", yaxt="n", main="xaxt='n', yaxt='n'", cex.lab=2, cex.main=2.4)


#  change axis tick labels
par(mfrow=c(1,2))

library(showtext)
font_add_google("David Libre", family="david")
showtext_auto()
par(family="david")
plot(mpg$displ, mpg$hwy, pch=16, col="seagreen", xaxt="n", ann=F)
axis(1, at=1:8, labels=paste0(1:8, "mpg"))
title(xlab="Engine Displacement", cex.lab=1.2, font.lab=2)
title(ylab="Highway miles per gallon", cex.lab=1.2, font.lab=2)

# pos
plot(mpg$displ, mpg$hwy, pch=16, axes=F, xlim=c(1,8), ylim=c(10,50))
axis(1, at=1:8, pos=10)
axis(2, at=seq(10,50,5), pos=1)
par(opar)



# -------------------------------------------------------------------------


plot(mpg$displ, mpg$hwy)
lines(x=c(2,6), y=c(15, 40), lty=3, lwd=3, col="seagreen3")
abline(20, 3, lty=2, lwd=1, col="navy")
abline(h=30, lty=1, lwd=3, col="orange")
abline(v=4.5, lty=6, lwd=3, col="steelblue3")
abline(lm(mpg$hwy~mpg$displ), lty=1, lwd=3, col="firebrick3")



# -------------------------------------------------------------------------


par(mfrow=c(1,2))
plot(mpg$displ, mpg$hwy, pch=16)
points(x=c(3, 6), y=c(15, 35), pch=17, cex=2.4, col="blue")
points(mean(mpg$displ), mean(mpg$hwy), pch=3, cex=3, col="firebrick3", lwd=6)

# 그룹별로 데이터 분할
library(dplyr)
iris %>% group_split(Species) -> sub

# 첫번째 그룹으로 plot 생성
plot(sub[[1]]$Sepal.Length, sub[[1]]$Petal.Length, pch=16, col="blue", xlim=c(4, 8), ylim=c(0,7))

# 나머지 그룹들은 순차적으로 점 도표표
points(sub[[2]]$Sepal.Length, sub[[2]]$Petal.Length, pch=16, col="red")
points(sub[[3]]$Sepal.Length, sub[[3]]$Petal.Length, pch=16, col="green")

# 범례 추가
legend("bottomright", col=c("blue", "red", "green"), legend=levels(iris$Species), pch=16, bty="n")
par(opar)




# -------------------------------------------------------------------------


library(showtext)

font_add_google("Nanum Myeongjo", family="nanummyeongjo")
showtext_auto()

par(family="nanummyeongjo")
plot(mpg$displ, mpg$hwy, pch=16)
text(7, 43, "배기량 대비 고속도로 연비", cex=1.2, font=2, adj=1)
text(mpg$displ, mpg$hwy, mpg$manufacturer, cex=0.8, pos=1)




# -------------------------------------------------------------------------


library(showtext)
font_add_google("Noto Serif KR", "notoserifkr")
showtext_auto()

par(family="notoserifkr")
plot(mpg$displ, mpg$hwy, pch=16)
mtext("배기량 대비 고속도로 연비", side=3, cex=2.5, font=2, line=2)




# -------------------------------------------------------------------------


# Dummy data
a <- seq(129,1)+4*runif(129,0.4)
b <- seq(1,129)^2+runif(129,0.98)
 
# Set the layout
nf <- layout(
  matrix(c(1,1,2,3), ncol=2, byrow=TRUE), 
  widths=c(3,1), 
  heights=c(2,2)
)

#Add the plots
hist(a , breaks=30 , border=F , col=rgb(0.1,0.8,0.3,0.5) , xlab="distribution of a" , main="")
boxplot(a , xlab="a" , col=rgb(0.8,0.8,0.3,0.5) , las=2)
boxplot(b , xlab="b" , col=rgb(0.4,0.2,0.3,0.5) , las=2)




# -------------------------------------------------------------------------


